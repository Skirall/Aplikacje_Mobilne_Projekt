package com.example.java_aplikacja;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SpaloneKalorieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spalone_kalorie);
    }
}