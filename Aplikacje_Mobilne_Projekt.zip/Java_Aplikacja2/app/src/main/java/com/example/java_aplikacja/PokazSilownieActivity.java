package com.example.java_aplikacja;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PokazSilownieActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pokaz_silownie);
    }
}